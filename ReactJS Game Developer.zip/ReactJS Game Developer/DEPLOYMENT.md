# Deployment Guide

## Quick Deploy to Vercel

1. **Install Vercel CLI** (if not already installed):

   ```bash
   npm install -g vercel
   ```

2. **Deploy the project**:

   ```bash
   cd "ReactJS Game Developer"
   vercel
   ```

3. **Follow the prompts**:

   - Set up and deploy: `Y`
   - Which scope: Select your account
   - Link to existing project: `N`
   - Project name: `spot-the-difference-game`
   - Directory: `./` (current directory)

4. **Production deployment**:
   ```bash
   vercel --prod
   ```

## Deploy to Netlify

### Method 1: Drag and Drop

1. Go to [Netlify](https://app.netlify.com)
2. Drag the entire project folder to the deploy area
3. Your site will be live instantly

### Method 2: Git Integration

1. Push your code to GitHub
2. Connect your GitHub repository to Netlify
3. Set build settings:
   - Build command: (leave empty)
   - Publish directory: (leave empty or set to `.`)

## Deploy to GitHub Pages

1. **Create a GitHub repository**
2. **Push your code**:

   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/spot-the-difference-game.git
   git push -u origin main
   ```

3. **Enable GitHub Pages**:
   - Go to Settings > Pages
   - Select source: Deploy from a branch
   - Branch: main
   - Folder: / (root)

## Local Development

### Using Python (Recommended)

```bash
# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
```

### Using Node.js

```bash
# Install live-server globally
npm install -g live-server

# Start server
live-server --port=8000
```

### Using PHP

```bash
php -S localhost:8000
```

Then open http://localhost:8000 in your browser.

## Environment Variables

No environment variables are needed for this static site.

## Custom Domain

### For Vercel:

1. Go to your project dashboard
2. Settings > Domains
3. Add your custom domain

### For Netlify:

1. Go to Site Settings > Domain Management
2. Add custom domain

## Performance Optimization

The game includes:

- Service Worker for offline support
- Optimized images (SVG format)
- Minified CSS and JavaScript (in production)
- Proper caching headers (via vercel.json)

## Troubleshooting

### Common Issues:

1. **CORS Errors**: Make sure you're serving the files over HTTP, not opening directly
2. **Images not loading**: Check that image paths in JSON files are correct
3. **Service Worker not working**: Ensure you're using HTTPS in production

### Browser Requirements:

- Modern browsers with ES6+ support
- JavaScript enabled
- Local storage support (for future features)
